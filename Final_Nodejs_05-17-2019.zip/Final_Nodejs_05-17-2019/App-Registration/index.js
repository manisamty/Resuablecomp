

const Joi = require('joi');
Joi.objectId = require('joi-objectid')(Joi);
const mongoose = require('mongoose');
const apps = require('./routes/apps');
const express = require('express');
const app = express();

//mongoose.connect('mongodb://localhost/appreg_db')

mongoose.connect("mongodb://localhost:27017/appreg_db", { useNewUrlParser: true })

    .then(() => console.log('Now connected to MongoDB!'))
    .catch(err => console.error('Something went wrong', err));
 
app.use(express.json());
app.use('/api/apps', apps);
const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening on port ${port}...`));




/*
https://localhost:8086/api/apps/

*/