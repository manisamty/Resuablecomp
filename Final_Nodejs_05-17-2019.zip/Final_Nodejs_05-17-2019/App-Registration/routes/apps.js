
const { App, validate } = require('../models/app');
const express = require('express');
const router = express.Router();
 
router.post('/', async (req, res) => {

    // First Validate The Request

    const { error } = validate(req.body);
    if (error) {
        return res.status(400).send(error.details[0].message);
    }
 
    // Check if this user already exisits

    let app = await App.findOne({ app_name: req.body.app_name });
    if (app) {
        return res.status(400).send('That App already exisits!');
    } else {

        // Register the new app if they do not exist yet

        app = new App({
            app_name: req.body.app_name,
        });
        await app.save();
        res.send(app);
        res.json({ message: 'App successfully Registered' });
    }
});
module.exports = router;