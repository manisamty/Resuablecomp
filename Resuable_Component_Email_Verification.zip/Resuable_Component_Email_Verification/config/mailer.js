module.exports = {
  MAILGUN_USER: 'manisamohanty55@gmail.com',
  MAILGUN_PASS: 'luvtolau'
};